# adept-utils

[![Travis](https://img.shields.io/travis/LLNL/adept-utils/master.svg?style=flat-square)](https://travis-ci.org/LLNL/adept-utils)
[![](https://img.shields.io/github/issues-raw/LLNL/adept-utils.svg?style=flat-square)](https://github.com/LLNL/adept-utils/issues)
[![](http://img.shields.io/badge/license-3--clause_BSD-blue.svg?style=flat-square)](LICENSE)

This project is a set of libraries for commonly useful routines for ADEPT code
projects.


## License

See the [LICENSE](LICENSE.md) file for license and distribution information.
