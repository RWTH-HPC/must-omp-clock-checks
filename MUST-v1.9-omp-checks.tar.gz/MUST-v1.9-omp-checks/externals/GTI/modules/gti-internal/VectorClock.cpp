/* This file is part of GTI (Generic Tool Infrastructure)
 *
 * Copyright (C)
 *  2008-2019 ZIH, Technische Universitaet Dresden, Federal Republic of Germany
 *  2008-2019 Lawrence Livermore National Laboratories, United States of America
 *  2013-2019 RWTH Aachen University, Federal Republic of Germany
 *
 * See the LICENSE file in the package base directory for details
 */

/**
 * @file VectorClock.cpp
 *       @see I_VectorClock.
 *
 *  @date 26.05.2021
 *  @author Felix Tomski
 */

#include "GtiApi.h"
#include "GtiMacros.h"
#include "I_CommProtocol.h"

#include "VectorClock.h"
#include <cstdint>
#include <ostream>
#include <sys/resource.h>
#include <tuple>
#include <utility>
#include <vector>

#include "BinomialTree.h"
#include "Clock.h"

// #define GTI_DEBUG 1

#ifdef GTI_DEBUG
#define VC_DEBUG 1
#endif

using namespace gti;

mGET_INSTANCE_FUNCTION(VectorClock);
mFREE_INSTANCE_FUNCTION(VectorClock);
mPNMPI_REGISTRATIONPOINT_FUNCTION(VectorClock);

//=============================
// Constructor
//=============================
VectorClock::VectorClock(const char* instanceName)
    : gti::ModuleBase<VectorClock, I_VectorClock>(instanceName), myNumProcs(0), id(-1), myClock(),
      clockQueues(), responseClocks(), lockClocks(), myPlaceMod(nullptr), myP2pIntraLayerTime(0)
{

    myMediationTime = 0;
    myMediateWaitTime = 0;
    myMediationRestarts = 0;

    // create sub modules
    std::vector<I_Module*> subModInstances;
    subModInstances = createSubModuleInstances();

    // handle sub modules
#define NUM_SUBS 4
    /* if (subModInstances.size() < NUM_SUBS) {
        std::cerr << "Module has not enough sub modules, check its analysis specification !(" <<
    __FILE__ << " @" << __LINE__ << ") " << std::endl; assert(0);
    } */
    if (subModInstances.size() > NUM_SUBS) {
        for (int i = NUM_SUBS; i < subModInstances.size(); i++)
            destroySubModuleInstance(subModInstances[i]);
    }

    // Initialize module data
    getWrapAcrossFunction("passVClockAcrossP2P", (GTI_Fct_t*)&myPassVClockAcrossP2PFunc);
    getWrapAcrossFunction("passUnlockClockToProxy", (GTI_Fct_t*)&myPassUnlockClockProxyFunc);
    getWrapAcrossFunction("passUnlockClockToEnd", (GTI_Fct_t*)&myPassUnlockClockEndFunc);
    getWrapAcrossFunction("passLockNotify", (GTI_Fct_t*)&myPassLockNotifyFunc);
    getWrapperFunction("syncNotify", (GTI_Fct_t*)&mySyncNotifyFunc);

    getWrapAcrossFunction("mediateSend", (GTI_Fct_t*)&myMediateSend);

    std::map<std::string, std::string> data = getData();

    if (data.find("id") != data.end())
        id = stoi(data["id"]);
    else {
        std::cerr << "[VClock] error: Could not find 'id' field in getData()" << std::endl;
        assert(0);
    }

    if (data.find("gti_level_1_size") != data.end()) {
        myNumProcs = stoi(data["gti_level_1_size"]);
    } else {
        std::cerr << "[VClock] error: Could not find 'gti_level_1_size' field in "
                     "getData()"
                  << std::endl;
        assert(0);
    }

    initialMustParallelId = 0;
    initialMustParallelId = static_cast<uint64_t>(1) << 32 | id;
    vectorClocks[initialMustParallelId] = SetClock(initialMustParallelId, 0);

    const char* COLL_STRAT = std::getenv("VC_STRAT");
    myCollStratMod = (I_CollStrat*)subModInstances[static_cast<int>(strToSColltrategy(COLL_STRAT))];
}

//=============================
// Destructor
//=============================
VectorClock::~VectorClock()
{
/* Collect time spent in collectives and P2P analysis functions */
#ifdef VC_DEBUG >= 3
    PNMPI_modHandle_t handle;
    PNMPI_Service_descriptor_t service;
    PNMPI_Service_Fct_t fct;
    MPI_Group myToolGroup;
    MPI_Comm myToolComm;

    int err = PNMPI_Service_GetModuleByName("split_processes", &handle);
    assert(err == PNMPI_SUCCESS);
    err = PNMPI_Service_GetServiceByName(handle, "SplitMod_getMySetComm", "p", &service);
    assert(err == PNMPI_SUCCESS);
    MPI_Comm fakeComm;
    ((int (*)(void*))service.fct)(&fakeComm);
    XMPI_Comm_dup(fakeComm, &myToolComm);
    XMPI_Comm_group(myToolComm, &myToolGroup);

    int rank, size;
    PMPI_Comm_rank(myToolComm, &rank);
    PMPI_Comm_size(myToolComm, &size);

    auto myCollIntraLayerTime = myCollStratMod->getCollIntraLayerTime();
    // printf(
    //     "IntraLayerP2pTime: %lu\nIntraLayerCollTime: %lu\n",
    //     myP2pIntraLayerTime,
    //     myCollStratMod->getCollIntraLayerTime());
    if (rank == 0) {
        std::vector<uint64_t> p2pTimes;
        std::vector<uint64_t> collTimes;
        std::vector<uint64_t> mediationTimes;
        std::vector<uint64_t> mediationWaitTimes;
        std::vector<uint64_t> mediationRestarts;
        std::vector<uint64_t> mediateGroupBuildTime;
        std::vector<uint64_t> SC_MERGE_TIMES;
        std::vector<uint64_t> SC_CONSTRUCTOR_TIMES;
        p2pTimes.resize(size);
        collTimes.resize(size);
        mediationTimes.resize(size);
        SC_MERGE_TIMES.resize(size);
        SC_CONSTRUCTOR_TIMES.resize(size);
        mediationWaitTimes.resize(size);
        mediateGroupBuildTime.resize(size);
        mediationRestarts.resize(size);
        PMPI_Gather(
            &myP2pIntraLayerTime,
            1,
            MPI_UINT64_T,
            p2pTimes.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &myCollIntraLayerTime,
            1,
            MPI_UINT64_T,
            collTimes.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &myMediationTime,
            1,
            MPI_UINT64_T,
            mediationTimes.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);

        PMPI_Gather(
            &myMediateWaitTime,
            1,
            MPI_UINT64_T,
            mediationWaitTimes.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &myMediationRestarts,
            1,
            MPI_UINT64_T,
            mediationRestarts.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &myMediateGroupBuildTime,
            1,
            MPI_UINT64_T,
            mediateGroupBuildTime.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &SetClock::SC_MERGE_TIME,
            1,
            MPI_UINT64_T,
            SC_MERGE_TIMES.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &SetClock::SC_CONSTRUCTOR_TIME,
            1,
            MPI_UINT64_T,
            SC_CONSTRUCTOR_TIMES.data(),
            1,
            MPI_UINT64_T,
            0,
            myToolComm);

        printf(
            "IntraLayerP2pTime: %lu %lu %f\nIntraLayerCollTime: %lu %lu %f\nMediationTime: %lu %lu "
            "%f\n",
            *std::min_element(p2pTimes.begin(), p2pTimes.end()),
            *std::max_element(p2pTimes.begin(), p2pTimes.end()),
            std::accumulate(p2pTimes.begin(), p2pTimes.end(), 0.0) / size,
            *std::min_element(collTimes.begin(), collTimes.end()),
            *std::max_element(collTimes.begin(), collTimes.end()),
            std::accumulate(collTimes.begin(), collTimes.end(), 0.0) / size,
            *std::min_element(mediationTimes.begin(), mediationTimes.end()),
            *std::max_element(mediationTimes.begin(), mediationTimes.end()),
            std::accumulate(mediationTimes.begin(), mediationTimes.end(), 0.0) / size);

        printf(
            "SC_MERGE_TIME: %lu %lu %f\n",
            *std::min_element(SC_MERGE_TIMES.begin(), SC_MERGE_TIMES.end()),
            *std::max_element(SC_MERGE_TIMES.begin(), SC_MERGE_TIMES.end()),
            std::accumulate(SC_MERGE_TIMES.begin(), SC_MERGE_TIMES.end(), 0.0) / size);

        printf(
            "SC_CONSTRUCTOR_TIMES: %lu %lu %f\n",
            *std::min_element(SC_CONSTRUCTOR_TIMES.begin(), SC_CONSTRUCTOR_TIMES.end()),
            *std::max_element(SC_CONSTRUCTOR_TIMES.begin(), SC_CONSTRUCTOR_TIMES.end()),
            std::accumulate(SC_CONSTRUCTOR_TIMES.begin(), SC_CONSTRUCTOR_TIMES.end(), 0.0) / size);

        printf(
            "MediationWaitTime: %lu %lu %f\n",
            *std::min_element(mediationWaitTimes.begin(), mediationWaitTimes.end()),
            *std::max_element(mediationWaitTimes.begin(), mediationWaitTimes.end()),
            std::accumulate(mediationWaitTimes.begin(), mediationWaitTimes.end(), 0.0) / size);

        printf(
            "MediationRestarts: %lu %lu %f\n",
            *std::min_element(mediationRestarts.begin(), mediationRestarts.end()),
            *std::max_element(mediationRestarts.begin(), mediationRestarts.end()),
            std::accumulate(mediationRestarts.begin(), mediationRestarts.end(), 0.0) / size);

        printf(
            "mediateGroupBuildTime: %lu %lu %f\n",
            *std::min_element(mediateGroupBuildTime.begin(), mediateGroupBuildTime.end()),
            *std::max_element(mediateGroupBuildTime.begin(), mediateGroupBuildTime.end()),
            std::accumulate(mediateGroupBuildTime.begin(), mediateGroupBuildTime.end(), 0.0) /
                size);

    } else {
        PMPI_Gather(&myP2pIntraLayerTime, 1, MPI_UINT64_T, NULL, 0, MPI_UINT64_T, 0, myToolComm);
        PMPI_Gather(&myCollIntraLayerTime, 1, MPI_UINT64_T, NULL, 0, MPI_UINT64_T, 0, myToolComm);
        PMPI_Gather(&myMediationTime, 1, MPI_UINT64_T, NULL, 0, MPI_UINT64_T, 0, myToolComm);
        PMPI_Gather(&myMediateWaitTime, 1, MPI_UINT64_T, NULL, 0, MPI_UINT64_T, 0, myToolComm);
        PMPI_Gather(
            &myMediateGroupBuildTime,
            1,
            MPI_UINT64_T,
            NULL,
            0,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(&myMediationRestarts, 1, MPI_UINT64_T, NULL, 0, MPI_UINT64_T, 0, myToolComm);
        PMPI_Gather(
            &SetClock::SC_MERGE_TIME,
            1,
            MPI_UINT64_T,
            NULL,
            0,
            MPI_UINT64_T,
            0,
            myToolComm);
        PMPI_Gather(
            &SetClock::SC_CONSTRUCTOR_TIME,
            1,
            MPI_UINT64_T,
            NULL,
            0,
            MPI_UINT64_T,
            0,
            myToolComm);
    }
#endif

    if (myCollStratMod)
        destroySubModuleInstance((I_Module*)myCollStratMod);
    myCollStratMod = NULL;

    // #if VC_DEBUG >= 1
    //    printf("[VClock] shutdown(%d): %s\n", id, clockToStr().c_str());
    struct rusage usage;
    int res = getrusage(RUSAGE_SELF, &usage);
    printf(
        "[VClock] shutdown(%d): mem=%ld, clk=%s\n",
        id,
        usage.ru_maxrss,
        getClock(initialMustParallelId).str().c_str());
    // #endif
}

//=============================
// init
//=============================
GTI_ANALYSIS_RETURN VectorClock::init(uint64_t mustParallelId)
{
    getPlaceMod(&myPlaceMod);
    // If we do not use openmp the threadid is always 0
    // In that case we change the initialMustParallelId to mustParallelId
    // and create a new clock entry
    if (initialMustParallelId != mustParallelId) {
        vectorClocks.erase(initialMustParallelId);
        initialMustParallelId = mustParallelId;
    }

    if (vectorClocks.find(initialMustParallelId) == vectorClocks.end()) {
        vectorClocks[initialMustParallelId] = SetClock(initialMustParallelId, 0);
    }
#if VC_DEBUG >= 2
    printf("[VClock] init(%d): %s\n", id, getClock(initialMustParallelId).str().c_str());
#endif

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// tick
//=============================

GTI_ANALYSIS_RETURN VectorClock::tick(uint64_t mustParallelId)
{
    // #if VC_DEBUG >= 1
    //     if (id < 0 || id >= getClock(mustParallelId).size()) {
    //         std::cerr << "[VClock] error: Invalid rank (" << id << ") for tick()" << std::endl;
    //         return GTI_ANALYSIS_FAILURE;
    //     }
    // #endif

    if (!myPlaceMod)
        getPlaceMod(&myPlaceMod);
    // myClock[id] += 1;
    getClock(mustParallelId).tick();

#if VC_DEBUG >= 1
    std::cout << "[VClock] tick(" << mustParallelId << "): " << getClock(mustParallelId).str()
              << std::endl;
#endif

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// bufferSignal
//=============================
GTI_ANALYSIS_RETURN
VectorClock::bufferSignal(AppId appRank, QueueId queueId, RequestId requestHandle)
{
    // TODO: is this used?

    GtiId targetPlaceId;
    getLevelIdForApplicationRank(appRank, &targetPlaceId);

    // #if VC_DEBUG >= 2
    //     std::cout << "[VClock] Buffering VClock " << id << " to " << targetPlaceId << " under
    //     handle "
    //               << requestHandle << std::endl;
    // #endif

#if VC_DEBUG >= 2
    std::cout << "[VClock] Buffering VClock " << id << " to " << targetPlaceId << " under handle "
              << std::endl;
#endif

    // requestTypeInfos.emplace(requestHandle, RequestType::send);
    // signalInfos.emplace(
    //     std::piecewise_construct,
    //     std::forward_as_tuple(requestHandle),
    //     std::forward_as_tuple(myClock, true, targetPlaceId, queueId));

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// addPersistentSendInfo
//=============================
GTI_ANALYSIS_RETURN
VectorClock::addPersistentSendInfo(AppId appRank, QueueId queueId, RequestId requestHandle)
{
    GtiId targetPlaceId;
    getLevelIdForApplicationRank(appRank, &targetPlaceId);

#if VC_DEBUG >= 2
    std::cout << "[VClock] Buffering VClock " << id << " to " << targetPlaceId << " under handle "
              << requestHandle << std::endl;
#endif

    requestTypeInfos.emplace(requestHandle, RequestType::persistent_send);
    myPersistentSendInfos.emplace(
        std::piecewise_construct,
        std::forward_as_tuple(requestHandle),
        std::forward_as_tuple(targetPlaceId, queueId, false));

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// addPersistentRecvInfo
//=============================
GTI_ANALYSIS_RETURN VectorClock::addPersistentRecvInfo(RequestId requestHandle, uint64_t comm)
{
    requestTypeInfos.emplace(requestHandle, RequestType::persistent_recv);
    myPersistentRecvInfos.emplace(
        std::piecewise_construct,
        std::forward_as_tuple(requestHandle),
        std::forward_as_tuple(comm, false));

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// bufferWait
//=============================
GTI_ANALYSIS_RETURN VectorClock::bufferWait(QueueId queueId, RequestId requestHandle)
{
#if VC_DEBUG >= 2
    printf("[VClock] Buffering Wait %d under handle %lu\n", id, requestHandle);
#endif

    requestTypeInfos.emplace(requestHandle, RequestType::receive);
    waitInfos.emplace(requestHandle, queueId);

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// cantor_pairing
//=============================
inline VectorClock::QueueId cantor_pairing(uint64_t comm, int tag)
{
    return ((comm + tag) * (comm + tag + 1)) / 2 + tag;
}

//=============================
// handleRequest
//=============================
GTI_ANALYSIS_RETURN
VectorClock::handleRequest(uint64_t mustParallelId, RequestId requestHandle, AppId source, int tag)
{
    auto info = requestTypeInfos.find(requestHandle);
    if (info == requestTypeInfos.end()) {
#ifdef VC_DEBUG
        printf("[VClock] %d could not handle request %lu\n", id, requestHandle);
#endif
        /* This is actually ok for handles corresponding to signals (e.g. MPI_Isend), because
        we
         * don't buffer signals */
        return GTI_ANALYSIS_SUCCESS;
    }

    GTI_ANALYSIS_RETURN returnVal = GTI_ANALYSIS_SUCCESS;

    switch (info->second) {
    case RequestType::send: {
        auto sInfo = signalInfos.find(requestHandle);
        returnVal = sendBufferedSignal(mustParallelId, sInfo->second);
        signalInfos.erase(sInfo);
        break;
    }
    case RequestType::persistent_send: {
        auto sInfo = myPersistentSendInfos.find(requestHandle);
        if (!sInfo->second.isActive)
            returnVal =
                signal(mustParallelId, 0, 0, sInfo->second.remotePlaceId, sInfo->second.queueId);
        sInfo->second.isActive = !sInfo->second.isActive;
        break;
    }
    case RequestType::receive: {
        auto wInfo = waitInfos.find(requestHandle);
        returnVal = waitForSignal(mustParallelId, source, cantor_pairing(wInfo->second, tag));
        waitInfos.erase(wInfo);
        break;
    }
    case RequestType::persistent_recv: {
        auto& wInfo = myPersistentRecvInfos.find(requestHandle)->second;
        if (wInfo.isActive)
            returnVal = waitForSignal(mustParallelId, source, cantor_pairing(wInfo.comm, tag));
        wInfo.isActive = !wInfo.isActive;
        break;
    }
    case RequestType::alltoall: {
        auto cInfo = collInfos.find(requestHandle);
        returnVal = internalA2a(
            mustParallelId,
            cInfo->second.groupRanks,
            cInfo->second.queueId,
            cInfo->second.clock,
            cInfo->second.localRank,
            cInfo->second.localRoot,
            cInfo->second.worldRoot);
        collInfos.erase(cInfo);
        break;
    }
    case RequestType::alltoone: {
        auto cInfo = collInfos.find(requestHandle);
        /* Root does not need to buffer its clock */
        GtiId rootId;
        getLevelIdForApplicationRank(cInfo->second.worldRoot, &rootId);
        if (id != rootId)
            returnVal = internalA2o(
                mustParallelId,
                cInfo->second.groupRanks,
                cInfo->second.queueId,
                cInfo->second.clock,
                cInfo->second.localRank,
                cInfo->second.localRoot,
                cInfo->second.worldRoot);
        else
            returnVal = internalA2o(
                mustParallelId,
                cInfo->second.groupRanks,
                cInfo->second.queueId,
                getClock(mustParallelId),
                cInfo->second.localRank,
                cInfo->second.localRoot,
                cInfo->second.worldRoot);
        collInfos.erase(cInfo);
        break;
    }
    case RequestType::onetoall: {
        auto cInfo = collInfos.find(requestHandle);
        /* Root does not need to buffer its clock */
        GtiId rootId;
        getLevelIdForApplicationRank(cInfo->second.worldRoot, &rootId);
        if (id == rootId)
            returnVal = internalO2a(
                mustParallelId,
                cInfo->second.groupRanks,
                cInfo->second.queueId,
                cInfo->second.clock,
                cInfo->second.localRank,
                cInfo->second.localRoot,
                cInfo->second.worldRoot);
        else
            returnVal = internalO2a(
                mustParallelId,
                cInfo->second.groupRanks,
                cInfo->second.queueId,
                getClock(mustParallelId),
                cInfo->second.localRank,
                cInfo->second.localRoot,
                cInfo->second.worldRoot);
        collInfos.erase(cInfo);
        break;
    }
    }

    requestTypeInfos.erase(info);

    return returnVal;
}

//=============================
// sendBufferedSignal
//=============================
GTI_ANALYSIS_RETURN
VectorClock::sendBufferedSignal(uint64_t mustParallelId, const SignalRequestInfo& info)
{
#if VC_DEBUG >= 1
    if (!myPassVClockAcrossP2PFunc) {
        std::cerr << "[VClock] error: myPassVClockAcrossFunc undefined" << std::endl;
        return GTI_ANALYSIS_FAILURE;
    }
#endif

#ifdef VC_DEBUG
    printf("[VClock] %d sending buffered clock to %d\n", id, info.remotePlaceId);
#endif
    auto encoding = info.clock.encode();
    (*myPassVClockAcrossP2PFunc)(
        &encoding[0],
        encoding.size(),
        id,
        info.isSync,
        0,
        info.queueId,
        info.remotePlaceId);

    // Original
    // TODO: is my adaption correct?
    // TODO: is originSequence correct, or should it be from info.clock?
    // (*myPassVClockAcrossP2PFunc)(
    //     info.clock.data(),
    //     myClock.size(),            <- why myClock.size()????
    //     id,
    //     info.isSync,
    //     0,
    //     info.queueId,
    //     info.remotePlaceId);

    // TODO: fix passing id instead of app rank
    return waitForResponse(mustParallelId, static_cast<int>(info.remotePlaceId), info.queueId);

    // TEMPORARY RETURN; TODO: REMOVE LATER
    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// signal
//=============================
GTI_ANALYSIS_RETURN
VectorClock::signal(
    uint64_t mustParallelId,
    int isSync,
    int isResponse,
    AppId appRank,
    QueueId queueId)
{
#if VC_DEBUG >= 1
    if (!myPassVClockAcrossP2PFunc) {
        std::cerr << "[VClock] error: myPassVClockAcrossFunc undefined" << std::endl;
        return GTI_ANALYSIS_FAILURE;
    }
#endif

    GtiId targetPlaceId;
    getLevelIdForApplicationRank(appRank, &targetPlaceId);
#if VC_DEBUG >= 2
    printf(
        "[VClock] Passing VClock from %d to %d under %lu, sync=%d\n",
        id,
        targetPlaceId,
        queueId,
        isSync,
        isResponse);
#endif

    auto encoding = getClock(mustParallelId).encode();
    (*myPassVClockAcrossP2PFunc)(
        &encoding[0],
        encoding.size(),
        id,
        isSync,
        isResponse,
        queueId,
        targetPlaceId);
    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// waitForResponse
//=============================
GTI_ANALYSIS_RETURN
VectorClock::waitForResponse(uint64_t mustParallelId, AppId appRank, QueueId queueId)
{
    GtiId originId;
    getLevelIdForApplicationRank(appRank, &originId);

    // auto responseClock = responseClocks[originId].find(queueId);

    // auto startTime = getUsecTime();
    // while (responseClock == responseClocks[originId].end()) {
    //     myPlaceMod->testIntralayer();
    //     responseClock = responseClocks[originId].find(queueId);
    // }
    // myP2pIntraLayerTime += getUsecTime() - startTime;

    auto peerIt = responseClocks[originId];
    /* Wait for the clock of the communication context (queueId) to arrive */
    auto responseQueue = peerIt.find(queueId);
    if (responseQueue == peerIt.end())
        responseQueue = peerIt
                            .emplace(
                                std::piecewise_construct,
                                std::forward_as_tuple(queueId),
                                std::forward_as_tuple())
                            .first;
    auto startTime = getUsecTime();
    while (responseClocks[originId][queueId].empty()) {
        myPlaceMod->testIntralayer();
    }
    myP2pIntraLayerTime += getUsecTime() - startTime;

    auto tmpClockContext = responseClocks[originId][queueId].front();
    getClock(mustParallelId).merge(tmpClockContext.clock);
    // #if VC_DEBUG >= 2
    //     std::cout << "[VClock] " << id << " merged clock " << responseClock->second.str() << "
    //     from "
    //               << originId << " directly to " << getClock(key).str() << std::endl;
    // #endif
    // responseClocks[originId].erase(responseClock);
    responseClocks[originId][queueId].pop();

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// receiveVClockP2P
//=============================
GTI_ANALYSIS_RETURN VectorClock::receiveVClockP2P(
    ClockEntry* clockEncoding,
    size_t encodingSize,
    GtiId originId,
    int isSync,
    int isResponse,
    QueueId queueId)
{
#if VC_DEBUG >= 1
    if (id == originId) {
        std::cerr << "[VClock] error: receiveClock() called on own id: " << id << std::endl;
        return GTI_ANALYSIS_FAILURE;
    }

    if (originId >= myNumProcs) {
        std::cerr << "[VClock] error: receiveClock() on " << id << " from invalid id: " << originId
                  << std::endl;
        return GTI_ANALYSIS_FAILURE;
    }
#endif

    /* Gets merged in waitForResponse */
    if (isResponse) {
        auto responseQueue = responseClocks[originId].find(queueId);
        if (responseQueue == responseClocks[originId].end()) {
            responseQueue = responseClocks[originId]
                                .emplace(
                                    std::piecewise_construct,
                                    std::forward_as_tuple(queueId),
                                    std::forward_as_tuple())
                                .first;
        }
        responseQueue->second.emplace(SetClock(clockEncoding, encodingSize), isSync, originId);
        return GTI_ANALYSIS_SUCCESS;
    }

    auto clockQueue = clockQueues[originId].find(queueId);
    if (clockQueue == clockQueues[originId].end()) {
        clockQueue = clockQueues[originId]
                         .emplace(
                             std::piecewise_construct,
                             std::forward_as_tuple(queueId),
                             std::forward_as_tuple())
                         .first;
#ifdef VC_DEBUG
        printf("[VClock] %d created empty queue through %d under %lu\n", id, originId, queueId);
#endif
    }

    /* Buffer clock under queue handle, gets merged in waitForSignal */
    clockQueue->second.emplace(SetClock(clockEncoding, encodingSize), isSync, originId);
#if VC_DEBUG >= 2
    printf(
        "[VClock] %d buffered clock from %d under %lu : %s, queue size: %lu \n",
        id,
        originId,
        queueId,
        clockQueue->second.front().clock.str().c_str(),
        clockQueue->second.size());
#endif

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// waitForSignal
//=============================
GTI_ANALYSIS_RETURN
VectorClock::waitForSignal(uint64_t mustParallelId, AppId originAppRank, QueueId queueId)
{
    GtiId originId;
    getLevelIdForApplicationRank(originAppRank, &originId);
#ifdef VC_DEBUG
    printf("[VClock] %d waitingForSignal from %d under %lu\n", id, originId, queueId);
#endif

    auto peerIt = clockQueues[originId];
    /* Wait for the clock of the communication context (queueId) to arrive */
    auto clockQueue = peerIt.find(queueId);
    if (clockQueue == peerIt.end())
        clockQueue = peerIt
                         .emplace(
                             std::piecewise_construct,
                             std::forward_as_tuple(queueId),
                             std::forward_as_tuple())
                         .first;
    auto startTime = getUsecTime();
    while (clockQueues[originId][queueId].empty()) {
        myPlaceMod->testIntralayer();

#ifdef VC_DEBUG
        printf("[VClock] %d waitingForSignal from %d under %lu (polling)\n", id, originId, queueId);
#endif
    }
    myP2pIntraLayerTime += getUsecTime() - startTime;

    auto tmpClockContext = clockQueues[originId][queueId].front();
#if VC_DEBUG >= 2
    printf(
        "[VClock] %d merging %s with %s from %d\n",
        id,
        getClock(mustParallelId).str().c_str(),
        tmpClockContext.clock.str().c_str(),
        originId);
#endif

    // mentioned in Fidge's paper because of overtaking
    if (!tmpClockContext.isSync) {
        // TODO: What is overtaking and how does that work with nested clocks?
        // if (myClock[originId] <= tmpClockContext.clock[originId])
        //     myClock[originId] += 1;
    }
    /* Send back own vector clock in case of synchronous communication. */
    else if (tmpClockContext.isSync) {
        // We send the clock proactively as a preanalysis
        // #if VC_DEBUG >= 2
        //         std::cout << "Passing receivers clock over from " << id << " to " << originId <<
        //         std::endl;
        // #endif
        //         auto encoding = getClock(key).encode();
        //         std::vector<int> originSequence(key.begin(), key.end());
        //         (*myPassVClockAcrossP2PFunc)(
        //             &encoding[0],
        //             encoding.size(),
        //             &originSequence[0],
        //             originSequence.size(),
        //             true,
        //             true,
        //             queueId,
        //             originId);
    }
    mergeClock(mustParallelId, tmpClockContext.clock);
    clockQueues[originId][queueId].pop();

#if VC_DEBUG >= 2
    printf(
        "[VClock] %d merged clock with %d clock to %s\n",
        id,
        originId,
        getClock(mustParallelId).str().c_str());
#endif

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// allToOne
//=============================
GTI_ANALYSIS_RETURN VectorClock::allToOne(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    SetClock newClock(getClock(mustParallelId));
    auto res =
        internalA2o(mustParallelId, groupRanks, queueId, newClock, localRank, localRoot, worldRoot);
    mergeClock(mustParallelId, newClock);

    return res;
}

//
//=============================
// internalA2o
//=============================
GTI_ANALYSIS_RETURN VectorClock::internalA2o(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    SetClock& clockToUse,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    GTI_ANALYSIS_RETURN res =
        myCollStratMod->reduce(clockToUse, clockToUse, localRoot, localRank, groupRanks, queueId);
    /* For non-blocking, we first merge on the buffered clock */
    if (localRank == localRoot && &clockToUse != &getClock(mustParallelId))
        mergeClock(mustParallelId, clockToUse);

    return res;
}

//=============================
// oneToAll
//=============================
GTI_ANALYSIS_RETURN VectorClock::oneToAll(
    uint64_t mustParallelId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot,
    const std::vector<int>& groupRanks,
    QueueId queueId)
{
    auto res = GTI_ANALYSIS_SUCCESS;
    if (localRoot != localRank) {
        SetClock newClock(getClock(mustParallelId));
        res = internalO2a(
            mustParallelId,
            groupRanks,
            queueId,
            newClock,
            localRank,
            localRoot,
            worldRoot);
        mergeClock(mustParallelId, newClock);
    }
    // if(localRoot != localRank) {
    //     res = mediator(queueId);
    //     mergeClock(mustParallelId, currCollClockBuf[queueId]);
    //     currCollClockBuf.erase(queueId);
    // }

    return res;
}

//=============================
// oneToAll
//=============================
GTI_ANALYSIS_RETURN VectorClock::internalO2a(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    SetClock& clockToUse,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    auto res = myCollStratMod->broadcast(clockToUse, localRoot, localRank, groupRanks, queueId);
    return res;
}

//=============================
// bufferA2aClock
//=============================
GTI_ANALYSIS_RETURN
VectorClock::bufferA2aClock(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    RequestId request,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    requestTypeInfos.emplace(request, RequestType::alltoall);
    collInfos.emplace(
        std::piecewise_construct,
        std::forward_as_tuple(request),
        std::forward_as_tuple(
            getClock(mustParallelId),
            groupRanks,
            localRank,
            localRoot,
            worldRoot,
            queueId));

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// bufferA2oClock
//=============================
GTI_ANALYSIS_RETURN
VectorClock::bufferA2oClock(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    RequestId request,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    requestTypeInfos.emplace(request, RequestType::alltoone);
    /* Root doesn't need to buffer its clock */
    GtiId rootId;
    getLevelIdForApplicationRank(worldRoot, &rootId);
    if (id != rootId)
        collInfos.emplace(
            std::piecewise_construct,
            std::forward_as_tuple(request),
            std::forward_as_tuple(
                getClock(mustParallelId),
                groupRanks,
                localRank,
                localRoot,
                worldRoot,
                queueId));
    else
        collInfos.emplace(
            std::piecewise_construct,
            std::forward_as_tuple(request),
            std::forward_as_tuple(
                getClock(mustParallelId),
                groupRanks,
                localRank,
                localRoot,
                worldRoot,
                queueId));

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// bufferO2aClock
//=============================
GTI_ANALYSIS_RETURN
VectorClock::bufferO2aClock(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    RequestId request,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    requestTypeInfos.emplace(request, RequestType::alltoone);
    /* Only root needs to save its clock, but other processes also need group
     * and rank infos */
    GtiId rootId;
    getLevelIdForApplicationRank(worldRoot, &rootId);
    if (id == rootId)
        collInfos.emplace(
            std::piecewise_construct,
            std::forward_as_tuple(request),
            std::forward_as_tuple(
                getClock(mustParallelId),
                groupRanks,
                localRank,
                localRoot,
                worldRoot,
                queueId));
    else
        collInfos.emplace(
            std::piecewise_construct,
            std::forward_as_tuple(request),
            std::forward_as_tuple(
                SetClock(),
                groupRanks,
                localRank,
                localRoot,
                worldRoot,
                queueId));

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// allToAll
//=============================
GTI_ANALYSIS_RETURN VectorClock::allToAll(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    auto res = mediator(queueId);
    if (res == GTI_ANALYSIS_FAILURE)
        return res;
    mergeClock(mustParallelId, currCollClockBuf[queueId].front());
    currCollClockBuf[queueId].pop();
    return res;
}

//=============================
// internal_A2a
//=============================
GTI_ANALYSIS_RETURN VectorClock::internalA2a(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    SetClock& initClock,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    auto res = myCollStratMod->allreduce(initClock, initClock, localRank, groupRanks, queueId);
    /* For non-blocking, we first merge on the buffered clock */
    if (!(&initClock == &getClock(mustParallelId)))
        mergeClock(mustParallelId, initClock);

    return res;

    // TEMPORARY RETURN; TODO: REMOVE LATER
    // return GTI_ANALYSIS_SUCCESS;
}

//=============================
// bufferUnlockClock
//=============================
GTI_ANALYSIS_RETURN VectorClock::bufferUnlockClock(
    ClockEntry* lockClock,
    size_t clockSize,
    LockId lockHandle,
    GtiId originId)
{

    // TODO: do we need the origin ancestor sequence/ key?
    SetClock clock(lockClock, clockSize);
#if VC_DEBUG >= 2
    printf(
        "[VClock] %d buffering unlock clock %s under %lu from %d\n",
        id,
        clock.str().c_str(),
        lockHandle,
        originId);
#endif
    auto it = lockClocks.find(lockHandle);
    if (it == lockClocks.end()) {
        lockClocks.insert(
            {lockHandle,
             std::pair<bool, ClockContext>(
                 //  {false, ClockContext(SetClock(lockClock, clockSize, originId), 0,
                 //  originId)})});
                 {false, ClockContext(clock, 0, originId)})});
    } else {
        // TODO: overwrite clock??
        // std::memcpy(it->second.second.clock.data(), lockClock, sizeof(ClockEntry) * clockSize);
        it->second.second.clock = clock;
        it->second.first = false;
    }

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// unlock
//=============================
GTI_ANALYSIS_RETURN VectorClock::unlock(uint64_t mustParallelId, LockId lockHandle, AppId appRank)
{
    GtiId placeId;
    getLevelIdForApplicationRank(appRank, &placeId);
#if VC_DEBUG >= 2
    printf(
        "[VClock] %d passing unlock clock %s under %lu to proxy %d\n",
        id,
        getClock(mustParallelId).str().c_str(),
        lockHandle,
        placeId);
#endif
    auto encoding = getClock(mustParallelId).encode();
    myPassUnlockClockProxyFunc(&encoding[0], encoding.size(), lockHandle, id, placeId);

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// lock
//=============================
GTI_ANALYSIS_RETURN VectorClock::lock(uint64_t mustParallelId, LockId lockHandle, AppId appRank)
{
    GtiId placeId;
    getLevelIdForApplicationRank(appRank, &placeId);
#if VC_DEBUG >= 2
    auto key = getKey(mustParallelId);
    printf(
        "[VClock] %d passing lock clock %s under %lu to proxy %d\n",
        id,
        getClock(mustParallelId).str().c_str(),
        lockHandle,
        placeId);
#endif
    myPassLockNotifyFunc(lockHandle, id, placeId);

    auto it = waitingForUnlockClock.emplace(lockHandle, true).first;

    auto startTime = getUsecTime();
    /* Wait for the clock of the process that releases the lock, gets directly merged in
    recvUnlockClock() */
    do {
        myPlaceMod->testIntralayer();
    } while (waitingForUnlockClock[lockHandle]);
    myP2pIntraLayerTime += getUsecTime() - startTime;
    waitingForUnlockClock.erase(lockHandle);

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// handleLockNotify
//=============================
GTI_ANALYSIS_RETURN VectorClock::handleLockNotify(LockId lockHandle, GtiId originId)
{
#if VC_DEBUG >= 2
    printf(
        "[VClock] %d trying to handle lock notification under %lu from %d\n",
        id,
        lockHandle,
        originId);
#endif

    auto it = lockClocks.find(lockHandle);
    /* Insert default clock of all 0's for first lock request */
    if (it == lockClocks.end()) {
        myPassUnlockClockEndFunc(NULL, 0, lockHandle, 0, originId);
        lockClocks.insert(
            {lockHandle,
             std::pair<bool, ClockContext>({true, ClockContext(SetClock(), 0, originId)})});

#if VC_DEBUG >= 2
        printf(
            "[VClock] %d handling lock notification under %lu from %d: sent "
            "empty clock\n",
            id,
            lockHandle,
            originId);
#endif
    } else {
        /* Wait for unlock */
        auto startTime = getUsecTime();
        while (lockClocks[lockHandle].first) {
            myPlaceMod->testIntralayer();
        }
        myP2pIntraLayerTime += getUsecTime() - startTime;

        /* Forward the clock received from the unlocking process to the one that just locked
         */
        auto encoding = it->second.second.clock.encode();
        myPassUnlockClockEndFunc(
            &encoding[0],
            encoding.size(),
            lockHandle,
            it->second.second.remotePlaceId,
            originId);
#if VC_DEBUG >= 2
        printf(
            "[VClock] %d handling lock notification under %lu from %d: sent "
            "clock%s\n",
            id,
            lockHandle,
            originId,
            it->second.second.clock.str().c_str());
#endif
        lockClocks.erase(it);
    }

    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// recvUnlockClock
//=============================
GTI_ANALYSIS_RETURN VectorClock::recvUnlockClock(
    uint64_t mustParallelId,
    ClockEntry* lockClock,
    size_t clockSize,
    LockId lockHandle,
    GtiId originId)
{
#if VC_DEBUG >= 2
    printf(
        "[VClock] %d received unlock clock %s under %lu from %d\n",
        id,
        SetClock(lockClock, clockSize).str().c_str(),
        lockHandle,
        originId);
#endif
    auto it = waitingForUnlockClock.find(lockHandle);
    it->second = false;
    if (lockClock)
        // TODO: do we need to originId/origin ancestor sequence for the SetClock? for merging
        // this should not be necessary...
        // Original: mergeClock(GtiClock(lockClock, myClock.size(), originId));
        mergeClock(mustParallelId, SetClock(lockClock, clockSize));
    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// mergeClock
//=============================
void VectorClock::mergeClock(uint64_t mustParallelId, const SetClock& other)
{
    // Check for changes in clock before merge and notify other modules
    // if (mySyncNotifyFunc) {
    //     for (int i = 0; i < getClock(mustParallelId).size(); i++) {
    //         if (i != id && getClock(mustParallelId)[i] < other[i])
    //             mySyncNotifyFunc(i, id);
    //     }
    // }
    getClock(mustParallelId).merge(other);
}

void VectorClock::createClock(uint64_t mustParallelId, uint64_t parent_mustParallelId)
{
    vectorClocks[mustParallelId] = SetClock(vectorClocks[parent_mustParallelId]);
}

void VectorClock::createClock(uint64_t mustParallelId, const SetClock& other)
{
    vectorClocks[mustParallelId] = SetClock(other);
}

void VectorClock::eraseClock(const uint64_t mustParallelId)
{
    if (vectorClocks.find(mustParallelId) != vectorClocks.end())
        vectorClocks.erase(mustParallelId);
}

void VectorClock::merge(const uint64_t mustParallelId, const SetClock& other)
{
    getClock(mustParallelId).merge(other);
    // print_clocks();
};

void VectorClock::print_clocks()
{
    std::cout << "Vector clocks (" << vectorClocks.size() << " elements)" << std::endl;
    for (auto mapIterator = vectorClocks.begin(); mapIterator != vectorClocks.end();
         mapIterator++) {
        auto MustParallelId = mapIterator->first;
        auto pid = static_cast<uint32_t>(MustParallelId & 0xFFFFFFFF);
        auto tid = static_cast<uint32_t>(MustParallelId >> 32);
        std::cout << "[" << MustParallelId << " (R: " << pid << ", T: " << tid << ")] "
                  << mapIterator->second.str() << std::endl;
    }
}

GTI_ANALYSIS_RETURN VectorClock::storeCollInfoA2A(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    return storeCollInfo(
        mustParallelId,
        CollectiveType::alltoall,
        groupRanks,
        queueId,
        localRank,
        localRoot,
        worldRoot);
}

GTI_ANALYSIS_RETURN VectorClock::storeCollInfoA2O(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    return storeCollInfo(
        mustParallelId,
        CollectiveType::alltoone,
        groupRanks,
        queueId,
        localRank,
        localRoot,
        worldRoot);
}

GTI_ANALYSIS_RETURN VectorClock::storeCollInfoO2A(
    uint64_t mustParallelId,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    // auto new_group = groupRanks;
    // new_group.erase(find(vec.begin(),vec.end(),localRoot));
    // return storeCollInfo(
    //     mustParallelId,
    //     CollectiveType::onetoall,
    //     new_group,
    //     queueId,
    //     localRank,
    //     localRoot,
    //     worldRoot);

    auto res = GTI_ANALYSIS_SUCCESS;
    if (localRank == localRoot) {
        SetClock newClock(getClock(mustParallelId));
        res = internalO2a(
            mustParallelId,
            groupRanks,
            queueId,
            newClock,
            localRank,
            localRoot,
            worldRoot);
        mergeClock(mustParallelId, newClock);
    }
    // else {
    //     // auto new_group = groupRanks;
    //     // new_group.erase(find(vec.begin(),vec.end(),localRoot));
    //     res = storeCollInfo(
    //         mustParallelId,
    //         CollectiveType::onetoall,
    //         groupRanks,
    //         queueId,
    //         localRank,
    //         localRoot,
    //         worldRoot);
    // }

    return res;
}

GTI_ANALYSIS_RETURN VectorClock::storeCollInfo(
    uint64_t mustParallelId,
    CollectiveType collType,
    const std::vector<int>& groupRanks,
    QueueId queueId,
    AppId localRank,
    AppId localRoot,
    AppId worldRoot)
{
    if (currcolls.find(queueId) == currcolls.end()) {
        currcolls.emplace(
            std::piecewise_construct,
            std::forward_as_tuple(queueId),
            std::forward_as_tuple(
                mustParallelId,
                getClock(mustParallelId),
                collType,
                groupRanks,
                localRank,
                localRoot,
                worldRoot,
                queueId));
    } else {
        currcolls.at(queueId).count += 1;
    }
    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// mediate
//=============================
GTI_ANALYSIS_RETURN VectorClock::mediator(QueueId queueId)
{
    while (currCollClockBuf[queueId].empty()) {
        currQId = queueId;

        if (currcolls.find(queueId) == currcolls.end()) {
            std::cerr << "[VClock][" << id
                      << "] error: Collective information not available for mediation -- size: "
                      << currcolls.size() << " queueId " << queueId << std::endl;
            return GTI_ANALYSIS_FAILURE;
        }

        if (!mediate(queueId)) {
            std::cerr << "[VClock] error: Mediation failed" << std::endl;
            return GTI_ANALYSIS_FAILURE;
        }

        if (currcolls.find(currQId) == currcolls.end()) {
            std::cerr << "[VClock] error: Mediation choose a collective that is unknown to the "
                         "tool thread"
                      << std::endl;
            return GTI_ANALYSIS_FAILURE;
        }
        auto& info = currcolls.at(currQId);
        currCollClockBuf[currQId].push(SetClock(getClock(info.mustParallelId)));
        // currcolls.at(currQId).clock = SetClock(getClock(info.mustParallelId));
        if (info.type == CollectiveType::alltoall) {
            internalA2a(
                info.mustParallelId,
                info.groupRanks,
                info.queueId,
                currCollClockBuf[currQId].back(),
                info.localRank,
                info.localRoot,
                info.worldRoot);
        } else {
            std::cerr << "[VClock] error: Mediation only works for all-to-all collectives"
                      << std::endl;
            return GTI_ANALYSIS_FAILURE;
        }

        currcolls.at(currQId).count -= 1;
        if (currcolls.at(currQId).count <= 0)
            currcolls.erase(currQId);
    }
    return GTI_ANALYSIS_SUCCESS;
}

//=============================
// mediate
//=============================
bool VectorClock::mediate(QueueId queueId)
{
    auto startTime = getUsecTime();
    isMediating = 1;
    if (!myMediateSend) {
        std::cerr << "[VClock] error: myMediateSend undefined" << std::endl;
        assert(0);
    }

    auto startBuild = getUsecTime();
    // Create a set of that includes all processes that are part of my stored collectives
    discoveryRanks.clear();
    // std::cout << "[VClock:" << id << "][" << queueId << "] Mediation stored these collInfos: ";
    for (auto& info : currcolls) {
        // std::cout << info.first << " ";
        for (auto rank : info.second.groupRanks) {
            if (id == rank ||
                (info.second.type == CollectiveType::onetoall && info.second.localRoot == rank))
                continue;
            discoveryRanks.insert(rank);
        }
    }
    // std::cout << std::endl;
    confirmationRanks = discoveryRanks;
    myMediateGroupBuildTime += getUsecTime() - startBuild;

    // Check if we buffered data for any rank that is in discoveryRanks
    for (auto it = discoveryBuf.cbegin(), next_it = it; it != discoveryBuf.cend(); it = next_it) {
        ++next_it;
        if (discoveryRanks.find(it->first) == discoveryRanks.end()) {
            // send out ignore message to buffered_data.first
            GtiId targetPlaceId;
            getLevelIdForApplicationRank(it->first, &targetPlaceId);
            (*myMediateSend)(id, 0, 1, 1, targetPlaceId);
            discoveryBuf.erase(it);
        }
    }

    //============
    // Discovery
    //============

    // Send queueId to other tool processes
    for (auto rank : discoveryRanks) {
        GtiId targetPlaceId;
        getLevelIdForApplicationRank(rank, &targetPlaceId);
        (*myMediateSend)(id, queueId, 0, 1, targetPlaceId);
    }

// Wait for queueIds
#if VC_DEBUG >= 2
    std::cout << "[VClock:" << id << "][" << queueId << "] Waiting for qIds" << std::endl;
#endif
    auto waitStart = getUsecTime();
    while (discoveryRanks.size() > discoveryBuf.size()) {
        myPlaceMod->testIntralayer();
    }
    myMediateWaitTime += getUsecTime() - waitStart;
#if VC_DEBUG >= 2
    std::cout << "[VClock:" << id << "][" << queueId << "] Done waiting for qIds" << std::endl;
#endif

    // Select smallest queueId
    for (auto qId : discoveryBuf) {
        if (currcolls.find(qId.second) != currcolls.end() && qId.second < currQId) {
            // std::cout << "[VClock:" << id << "][" << queueId << "] Updated currQId from " <<
            // currQId
            //           << " to " << qId << std::endl;
            currQId = qId.second;
        }
    }

    // std::cout << "[VClock:" << id << "][" << queueId << "] FINISHED DISCOVERY " << std::endl;

    discoveryRanks.clear();
    discoveryBuf.clear();

    //============
    // Confirmation
    //============

    // Send currQId to other tool processes
    for (auto rank : confirmationRanks) {
        GtiId targetPlaceId;
        getLevelIdForApplicationRank(rank, &targetPlaceId);
        (*myMediateSend)(id, currQId, 0, 0, targetPlaceId);
    }

    // Wait for currQIds

#if VC_DEBUG >= 2
    std::cout << "[VClock:" << id << "][" << queueId << "] Waiting for currQIds" << std::endl;
#endif
    waitStart = getUsecTime();
    while (confirmationRanks.size() > confirmationBuf.size()) {
        myPlaceMod->testIntralayer();
    }
    myMediateWaitTime += getUsecTime() - waitStart;
#if VC_DEBUG >= 2
    std::cout << "[VClock:" << id << "][" << queueId << "] Done Waiting for currQIds" << std::endl;
#endif

    int num_confirm = 0;
    bool result = true;
    for (auto& rank : currcolls.at(currQId).groupRanks) {
        if (rank == id || (currcolls.at(currQId).type == CollectiveType::onetoall &&
                           currcolls.at(currQId).localRoot == rank))
            continue;
        // std::cout << "[VClock:" << id << "][" << queueId << "] checking rank " << rank <<
        // std::endl;
        if (confirmationBuf.find(rank) == confirmationBuf.end()) {
            // std::cout << "[VClock:" << id << "][" << queueId << "] rank " << rank
            //           << " not in confirmationBuf" << std::endl;
            result = false;
        } else if (confirmationBuf.at(rank) != currQId) {
            // std::cout << "[VClock:" << id << "][" << queueId << "] rank " << rank << " choose "
            //           << confirmationBuf.at(rank) << "instead of " << currQId << std::endl;
            result = false;
        } else {
            num_confirm++;
        }
    }

    // if (num_confirm == currcolls.at(currQId).groupRanks.size() - 1)
    //     res = true;

    // if (currQId != queueId)
    //     std::cout << "[VClock:" << id << "][" << queueId << "] Mediation choose: " << currQId
    //               << ", instead of " << queueId << std::endl;

    // if (result == false) {
    //     std::cout << "[VClock:" << id << "][" << queueId
    //               << "] Mediation failed -> restarting (num_confirm: " << num_confirm
    //               << " -- expected: " << currcolls.at(currQId).groupRanks.size() - 1
    //               << " -- confirmationBuf size: " << confirmationBuf.size()
    //               << " -- confirmationRanks.size(): " << confirmationRanks.size() << ")"
    //               << std::endl;
    // } else {
    //     std::cout << "[VClock:" << id << "][" << queueId
    //               << "] Mediation SUCCESS (num_confirm: " << num_confirm
    //               << " -- expected: " << currcolls.at(currQId).groupRanks.size() - 1
    //               << " -- confirmationBuf size: " << confirmationBuf.size()
    //               << " -- confirmationRanks.size(): " << confirmationRanks.size() << ")"
    //               << std::endl;
    // }

    if (result == false)
        myMediationRestarts++;

    confirmationRanks.clear();
    confirmationBuf.clear();
    isMediating = 0;
    myMediationTime += getUsecTime() - startTime;
    return result;
}

//=============================
// recvMediation
//=============================
GTI_ANALYSIS_RETURN
VectorClock::recvMediation(int originRank, QueueId queueId, int ignore, int isDiscovery)
{
    if (isMediating && isDiscovery) {
        // Send ignore message if we received a message from an rank that is not in
        // discoveryRanks
        if (discoveryRanks.find(originRank) == discoveryRanks.end()) {
            GtiId targetPlaceId;
            getLevelIdForApplicationRank(originRank, &targetPlaceId);
            // std::cout << "[VClock:" << id << "][recvMediation] sending ignore message to  "
            //           << originRank << std::endl;
            (*myMediateSend)(id, 0, 1, isDiscovery, targetPlaceId);
            return GTI_ANALYSIS_SUCCESS;
        } else if (ignore) {
            //  std::cout << "[VClock:" << id << "][recvMediation] received ignore message from
            //  "
            //           << originRank << std::endl;
            confirmationRanks.erase(originRank);
            return GTI_ANALYSIS_SUCCESS;
        }
    }

    if (isDiscovery) {
        discoveryBuf[originRank] = queueId;
    } else {
        confirmationBuf[originRank] = queueId;
    }

    return GTI_ANALYSIS_SUCCESS;
}