/* This file is part of GTI (Generic Tool Infrastructure)
 *
 * Copyright (C)
 *  2008-2019 ZIH, Technische Universitaet Dresden, Federal Republic of Germany
 *  2008-2019 Lawrence Livermore National Laboratories, United States of America
 *  2013-2019 RWTH Aachen University, Federal Republic of Germany
 *
 * See the LICENSE file in the package base directory for details
 */

/**
 * @file VectorClock.h
 *       @see I_VectorClock.
 *
 *  @date 26.05.2021
 *  @author Felix Tomski
 */

#include "I_CollStrat.h"
#include "I_VectorClock.h"
#include "ModuleBase.h"

#include "Clock.h"
#include "VectorClockApi.h"

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <limits.h> /* for CHAR_BIT */
#include <map>
#include <memory>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <sys/time.h>

#ifndef VECTORCLOCK_H
#define VECTORCLOCK_H

namespace gti
{

class VectorClock : public ModuleBase<VectorClock, I_VectorClock>
{
  public:
    class ClockContext;
    class CollRequestInfo;
    class SignalRequestInfo;
    class WaitRequestInfo;

    // typedef unsigned long long ClockEntry;
    typedef unsigned long long ClockEntry;
    typedef uint64_t QueueId;
    typedef uint64_t LockId;
    typedef unsigned long RequestId;
    typedef int AppId; /* Needs to be translated by getLevelIdForApplicationRank() */
    typedef int GtiId;
    typedef std::queue<ClockContext> ClockQueue;

    /* Stores received clock and further information for P2P communication */
    class ClockContext
    {
      public:
        SetClock clock;
        int isSync;
        GtiId remotePlaceId;

        ClockContext() : clock(), isSync(), remotePlaceId() {}

        ClockContext(SetClock&& c, int s, GtiId placeId)
            : clock(std::forward<SetClock>(c)), isSync(s), remotePlaceId(placeId)
        {
        }

        ClockContext(const SetClock& c, int s, GtiId placeId)
            : clock(c), isSync(s), remotePlaceId(placeId)
        {
        }
    }; /*class ClockContext*/

    /* Request types for non-blocking communication which require a second call for completion */
    enum class RequestType {
        send,
        receive,
        alltoone,
        alltoall,
        onetoall,
        persistent_send,
        persistent_recv
    }; /*enum class RequestType*/

    enum class CollectiveType { alltoone, alltoall, onetoall };

    /* Stores context information for non-blocking collective communication */
    class CollRequestInfo
    {
      public:
        SetClock clock; /* The local vector clock at communication initialization */
        const std::vector<int> groupRanks;
        AppId localRank;
        AppId localRoot;
        AppId worldRoot;
        QueueId queueId;
        CollRequestInfo(
            SetClock&& c,
            const std::vector<int>& gr,
            AppId lrank,
            AppId lroot,
            AppId wroot,
            QueueId q)
            : clock(std::forward<SetClock>(c)), groupRanks(gr), localRank(lrank),
              localRoot(lroot), worldRoot(wroot), queueId(q){};

        CollRequestInfo(
            const SetClock& c,
            const std::vector<int>& gr,
            AppId lrank,
            AppId lroot,
            AppId wroot,
            QueueId q)
            : clock(c), groupRanks(gr), localRank(lrank), localRoot(lroot), worldRoot(wroot),
              queueId(q){};
    }; /*class CollRequestInfo*/

    /* Stores context information for collective communication */
    class CollInfo
    {
      public:
        uint64_t mustParallelId;
        SetClock clock; /* The local vector clock at communication initialization */
        CollectiveType type;
        const std::vector<int> groupRanks;
        AppId localRank;
        AppId localRoot;
        AppId worldRoot;
        QueueId queueId;
        int count = 1;
        CollInfo(
            uint64_t pId,
            SetClock&& c,
            CollectiveType t,
            const std::vector<int>& gr,
            AppId lrank,
            AppId lroot,
            AppId wroot,
            QueueId q)
            : clock(std::forward<SetClock>(c)), mustParallelId(pId), type(t), groupRanks(gr),
              localRank(lrank), localRoot(lroot), worldRoot(wroot), queueId(q){};
        CollInfo(
            uint64_t pId,
            const SetClock& c,
            CollectiveType t,
            const std::vector<int>& gr,
            AppId lrank,
            AppId lroot,
            AppId wroot,
            QueueId q)
            : clock(c), mustParallelId(pId), type(t), groupRanks(gr), localRank(lrank),
              localRoot(lroot), worldRoot(wroot), queueId(q){};
    }; /*class CollInfo*/

    /* Stores a signal for non-blocking P2P communication (currently unused) */
    class SignalRequestInfo
    {
      public:
        SetClock clock;
        int isSync;
        GtiId remotePlaceId;
        QueueId queueId;
        SignalRequestInfo(SetClock&& c, int s, GtiId r, QueueId q)
            : clock(std::forward<SetClock>(c)), isSync(s), remotePlaceId(r), queueId(q){};

        SignalRequestInfo(const SetClock& c, int s, GtiId r, QueueId q)
            : clock(c), isSync(s), remotePlaceId(r), queueId(q){};
    }; /*class SignalRequestInfo*/

    class PersistentSendInfo
    {
      public:
        GtiId remotePlaceId;
        QueueId queueId;
        bool isActive;
        PersistentSendInfo(GtiId r, QueueId q, bool active)
            : remotePlaceId(r), queueId(q), isActive(active){};
    }; /*class SignalRequestInfo*/

    class PersistentRecvInfo
    {
      public:
        uint64_t comm;
        bool isActive;
        PersistentRecvInfo(QueueId c, bool active) : comm(c), isActive(active){};
    }; /*class SignalRequestInfo*/

    /**
     * Constructor.
     * @param instanceName name of this module instance.
     */
    VectorClock(const char* instanceName);

    /**
     * Destructor.
     */
    virtual ~VectorClock(void);

    /**
     * @see I_VectorClock.
     */
    GTI_ANALYSIS_RETURN tick(uint64_t mustParallelId) override;

    /**
     * @see I_VectorClock.
     */
    GTI_ANALYSIS_RETURN init(uint64_t mustParallelId) override;

    //=======================================-
    // Blocking point-to-point communication
    //========================================
    GTI_ANALYSIS_RETURN receiveVClockP2P(
        ClockEntry* clockEncoding,
        size_t encodingSize,
        GtiId originId,
        int isSync,
        int isResponse,
        QueueId queueId) override;

    GTI_ANALYSIS_RETURN
    waitForSignal(uint64_t mustParallelId, AppId originAppRank, QueueId queueId) override;
    GTI_ANALYSIS_RETURN
    waitForResponse(uint64_t mustParallelId, AppId originAppRank, QueueId queueId) override;

    //=======================================-
    // Blocking collective communication
    //========================================
    GTI_ANALYSIS_RETURN allToOne(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;
    GTI_ANALYSIS_RETURN oneToAll(
        uint64_t mustParallelId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot,
        const std::vector<int>& groupRanks,
        QueueId queueId) override;
    GTI_ANALYSIS_RETURN allToAll(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;

    GTI_ANALYSIS_RETURN storeCollInfoA2A(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;

    GTI_ANALYSIS_RETURN storeCollInfoA2O(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;

    GTI_ANALYSIS_RETURN storeCollInfoO2A(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;

    GTI_ANALYSIS_RETURN storeCollInfo(
        uint64_t mustParallelId,
        CollectiveType collType,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot);

    GTI_ANALYSIS_RETURN recvMediation(int originRank, QueueId queueId, int ignore, int isDiscovery) override;
    bool mediate(QueueId queueId);
    GTI_ANALYSIS_RETURN mediator(QueueId queueId);

    //=======================================-
    // Non-blocking communication
    //========================================
    GTI_ANALYSIS_RETURN
    handleRequest(uint64_t mustParallelId, RequestId requestHandle, AppId source, int tag) override;
    /* Point-to-point */
    GTI_ANALYSIS_RETURN bufferWait(QueueId queueId, RequestId requestHandle) override;
    GTI_ANALYSIS_RETURN
    bufferSignal(int appRank, QueueId queueId, RequestId requestHandle) override;
    GTI_ANALYSIS_RETURN
    signal(uint64_t mustParallelId, int isSync, int isResponse, AppId appRank, QueueId queueId)
        override;
    GTI_ANALYSIS_RETURN sendBufferedSignal(uint64_t mustParallelId, const SignalRequestInfo& info);
    GTI_ANALYSIS_RETURN
    addPersistentSendInfo(AppId appRank, QueueId queueId, RequestId requestHandle) override;
    GTI_ANALYSIS_RETURN addPersistentRecvInfo(RequestId requestHandle, uint64_t comm) override;
    /* Collective */
    GTI_ANALYSIS_RETURN bufferA2aClock(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        RequestId request,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;
    GTI_ANALYSIS_RETURN bufferA2oClock(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        RequestId request,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;
    GTI_ANALYSIS_RETURN bufferO2aClock(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        RequestId request,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot) override;

    //=======================================-
    // Resource-bound analysis functions
    //========================================
    GTI_ANALYSIS_RETURN
    bufferUnlockClock(ClockEntry* lockClock, size_t clockSize, LockId lockHandle, GtiId originId)
        override;
    GTI_ANALYSIS_RETURN unlock(uint64_t mustParallelId, LockId lockHandle, AppId appRank) override;
    GTI_ANALYSIS_RETURN lock(uint64_t mustParallelId, LockId lockHandle, AppId appRank) override;
    GTI_ANALYSIS_RETURN
    recvUnlockClock(
        uint64_t mustParallelId,
        ClockEntry* lockClock,
        size_t clockSize,
        LockId lockHandle,
        GtiId originId) override;
    GTI_ANALYSIS_RETURN handleLockNotify(LockId lockHandle, GtiId originId) override;

    /* Exposing helper functions / getters for other modules */
    GtiId getId() const override { return id; };
    ClockEntry getLocalClockValue() const override { return myClock.data()[id]; };
    ClockEntry getClockValue(const int appRank) const override { return myClock.data()[appRank]; };

    // SetClock getClock(const uint64_t mustParallelId) const override {
    //     auto key = keyMap[mustParallelId];
    //     return vectorClocks[key];
    // };

    std::string clockToStr() const { return myClock.toStr(); }

  protected:
    passVClockAcrossP2PP myPassVClockAcrossP2PFunc;
    passUnlockClockToProxyP myPassUnlockClockProxyFunc;
    passLockNotifyP myPassLockNotifyFunc;
    passUnlockClockToEndP myPassUnlockClockEndFunc;
    syncNotifyP mySyncNotifyFunc;
    mediateSendP myMediateSend;

    I_CollStrat*
        myCollStratMod; /* Generic module for implementation of collective analysis functions */
    I_Place* myPlaceMod;

  private:
    uint64_t myP2pIntraLayerTime;
    uint64_t myMediationTime;
    uint64_t myMediateWaitTime;
    uint64_t myMediationRestarts = 0;
    uint64_t myMediateGroupBuildTime = 0;
    uint64_t getUsecTime() const
    {
        struct timeval t;
        gettimeofday(&t, NULL);
        return t.tv_sec * 1000000 + t.tv_usec;
    }

    size_t myNumProcs;
    Clock myClock;
    GtiId id;
    uint64_t initialMustParallelId;

    void mergeClock(uint64_t mustParallelId, const SetClock& other);

    /* Point to point */
    /* For each id map the id of a p2p communication (Send+Recv) to the
     * received clock from the other process and communication information.
     * First pair entry is set by waiting process for direct merging in receive
     * function. */
    std::map<GtiId, std::unordered_map<QueueId, ClockQueue>> clockQueues;
    /* Per channel/queue we can only wait for one other process to respond in
     * synchronous communication mode so we do not need a queue here. */
    std::map<GtiId, std::unordered_map<QueueId, ClockQueue>> responseClocks;

    QueueId currQId;
    int numQids;
    int discoveriesReceived = 0;
    int isMediating = 0;
    // std::vector<QueueId> confirmationBuf;
    // std::vector<QueueId> discoveryBuf;

    std::unordered_map<int, QueueId> confirmationBuf;
    std::unordered_map<int, QueueId> discoveryBuf;

    std::set<int> confirmationRanks;
    std::set<int> discoveryRanks;
    std::unordered_map<QueueId, CollInfo> currcolls;
    std::unordered_map<QueueId, std::queue<SetClock>> currCollClockBuf;

    /* Non-blocking */
    std::unordered_map<RequestId, RequestType> requestTypeInfos;
    std::unordered_map<RequestId, CollRequestInfo> collInfos;
    std::unordered_map<RequestId, SignalRequestInfo> signalInfos;
    std::unordered_map<RequestId, QueueId> waitInfos;
    std::unordered_map<RequestId, PersistentSendInfo> myPersistentSendInfos;
    std::unordered_map<RequestId, PersistentRecvInfo> myPersistentRecvInfos;

    /* Resource-bound */
    std::unordered_map<LockId, std::pair<bool, ClockContext>> lockClocks;
    std::unordered_map<LockId, bool> waitingForUnlockClock;

    /* Helper functions used for blocking and non-blocking collective communication */
    GTI_ANALYSIS_RETURN internalA2a(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        SetClock& initClock,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot);
    GTI_ANALYSIS_RETURN internalA2o(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        SetClock& clockToUse,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot);
    GTI_ANALYSIS_RETURN internalO2a(
        uint64_t mustParallelId,
        const std::vector<int>& groupRanks,
        QueueId queueId,
        SetClock& clockToUse,
        AppId localRank,
        AppId localRoot,
        AppId worldRoot);

    // TODO: Find a better place for them
    std::deque<int> ancestorsArray2Deque(int size, int* ancestors) const override
    {
        std::deque<int> q;
        q.push_back(id);
        // Skip level 0 and replace it with the rank
        for (int i = 1; i < size; i++) {
            q.push_back(ancestors[i]);
        }
        return q;
    }

    std::string deque2String(const std::deque<int>& queue) override
    {
        std::ostringstream oss;
        oss << "[ ";
        for (const auto& elem : queue) {
            oss << elem << " ";
        }
        oss << "]";
        return oss.str();
    }

    struct DequeHash {
        size_t operator()(const std::deque<int>& deque) const
        {
            size_t hash = 0;
            for (const int& value : deque) {
                hash ^= std::hash<int>{}(value) + 0x9e3779b9 + (hash << 6) + (hash >> 2);
            }
            return hash;
        }
    };

    // Maps mustParallelId to vectorclocks
    std::unordered_map<uint64_t, SetClock> vectorClocks;
    // Maps MustParallelId->threadId (int) to SetClock keys that can be used to find a
    // SetClock in the member vectorClocks
    std::unordered_map<uint64_t, std::deque<int>> keyMap;

    SetClock& getClock(const uint64_t mustParallelId) override
    {
        if(vectorClocks.find(mustParallelId) != vectorClocks.end())
            return vectorClocks.at(mustParallelId);
        // If mustParallelId is not found return the initial clock
        // This is the case if we have a multi-threaded application but the multi-threaded synchronization is not tracked
        return vectorClocks.at(initialMustParallelId);
    };

    // SetClock& getClock(const std::deque<int>& ancestorSequence) override
    // {
    //     return vectorClocks.at(ancestorSequence);
    // };

    std::deque<int> getKey(const uint64_t mustParallelId) const override
    {
        if (keyMap.find(mustParallelId) != keyMap.end())
            return keyMap.at(mustParallelId);
        else
            return ancestorsArray2Deque(-1, nullptr);
    }

    void addKey(const uint64_t mustParallelId, std::deque<int> ancestorSequence) override
    {
        keyMap[mustParallelId] = ancestorSequence;
    };

    void eraseKey(const uint64_t mustParallelId) override { keyMap.erase(mustParallelId); };
    void merge(const uint64_t mustParallelId, const SetClock& other) override;
    void createClock(uint64_t mustParallelId, uint64_t parent_mustParallelI) override;
    void createClock(uint64_t mustParallelId, const SetClock& other) override;
    void eraseClock(const uint64_t mustParallelId) override;
    void print_clocks() override;

    bool doesClockExist(const uint64_t mustParallelId) const override
    {
        if (vectorClocks.find(mustParallelId) != vectorClocks.end())
            return true;
        return false;
    }

}; /*class VectorClock*/

} /*namespace gti*/

#endif /*VECTORCLOCK_H */
